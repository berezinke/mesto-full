# mesto-full
Проект `Mesto`, включающий фронтенд и бэкенд части приложения со следующими возможностями: авторизации и регистрации пользователей, операции с карточками и пользователями.

Ссылка на сайт:

http://mesto-server.students.nomoredomains.icu

https://mesto-server.students.nomoredomains.icu

ip 158.160.37.181
Frontend https:// mesto-server.students.nomoredomains.icu
Backend https:// api.mesto-server.students.nomoredomains.icu

Путь на сервере berezinke@mesto/mesto-full