function Footer() {
    return (
      <footer className="footer">
        <p className="footer__copyright">
          &copy; MestoFull Russia
        </p>
      </footer>
    );
  }
  
export default Footer;